package com.example.testbottomnavigation.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.testbottomnavigation.R;
import com.example.testbottomnavigation.domain.Course;

import java.util.List;

public class CourseAdapter extends ArrayAdapter<Course> {
    private int resourceID;

    public CourseAdapter(Context context,int textViewResourceId, List<Course> objects){
        super(context, textViewResourceId, objects);
        resourceID = textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        Course course = getItem(position);
        View view = LayoutInflater.from(getContext()).inflate(resourceID, parent, false);
        ImageView courseImage = view.findViewById(R.id.course_image);
        TextView courseName = view.findViewById(R.id.course_name);
        courseImage.setImageResource(course.getImageID());
        courseName.setText(course.getName());

        return view;
    }
}
