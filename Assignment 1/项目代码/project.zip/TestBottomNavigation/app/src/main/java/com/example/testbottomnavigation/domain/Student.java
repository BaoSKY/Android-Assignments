package com.example.testbottomnavigation.domain;

public class Student {
    private String ID;
    private String name;
}
