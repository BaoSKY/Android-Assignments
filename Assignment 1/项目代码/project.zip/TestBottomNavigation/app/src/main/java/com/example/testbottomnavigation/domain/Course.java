package com.example.testbottomnavigation.domain;

public class Course {
    //The detailed course introductions:
    //such as course info , syllabus, registration and calendar and so on.
    private String ID;
    private String name;
    private Teacher teacher;
    private String information;
    private String syllabus;
    private String calendar;

    private int imageID;

    public Course(String name, int imageID){
        this.name = name;
        this.imageID = imageID;

        //Set default value.
        this.ID = "C-123456";
        this.teacher = new Teacher("T-123456", "Dr.Bao");
        this.information = "Here is information of course " + this.ID + ".";
        this.syllabus = "Here is syllabus of course " + this.ID + ".";
        this.calendar = "9:00-11:00 Mon";
    }

    public void setID(String id) { this.ID = id; }

    public String getID() { return this.ID; }

    public void setName(String name) { this.name = name; }

    public String getName(){
        return this.name;
    }

    public void setTeacher(Teacher teacher) { this.teacher = teacher; }

    public Teacher getTeacher() { return this.teacher; }

    public void setInformation(String information) { this.information = information; }

    public String getInformation() { return this.information; }

    public void setSyllabus(String syllabus) { this.syllabus = syllabus; }

    public String getSyllabus() { return this.syllabus; }

    public void setCalendar(String calendar) { this.calendar = calendar; }

    public String getCalendar() { return this.calendar; }

    public void setImageID(int imageID) { this.imageID = imageID; }

    public int getImageID(){
        return this.imageID;
    }
}
