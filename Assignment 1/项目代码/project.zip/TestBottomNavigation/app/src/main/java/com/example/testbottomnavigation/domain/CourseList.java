package com.example.testbottomnavigation.domain;

import com.example.testbottomnavigation.R;

import java.util.ArrayList;

public class CourseList{
    public static ArrayList<Course> courses;

    public CourseList(){

    }

    public void initCourseList(){
        if(courses == null){
            courses = new ArrayList<>();
            String[] courseName = { "微积分", "线性代数", "数据结构", "移动应用开发", "信息安全理论和实践", "数据库理论" };
            int[] courseImgID = new int[courseName.length];
            for (int i = 0; i < courseImgID.length; i++) {
                courseImgID[i] = R.drawable.ic_launcher_background;
            }
            //int[] courseImgID = {R.drawable.ic_launcher_background, R.drawable.ic_launcher_background, R.drawable.ic_launcher_background, R.drawable.ic_launcher_background};
            for(int i = 0; i < courseName.length; i++){
                courses.add(new Course(courseName[i], courseImgID[i]));
            }
        }
    }
}
