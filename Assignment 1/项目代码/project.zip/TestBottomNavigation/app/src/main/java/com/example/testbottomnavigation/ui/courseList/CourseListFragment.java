package com.example.testbottomnavigation.ui.courseList;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.testbottomnavigation.R;
import com.example.testbottomnavigation.adapter.CourseAdapter;
import com.example.testbottomnavigation.domain.CourseList;
import com.example.testbottomnavigation.ui.couresDetail.CourseDetailFragment;

public class CourseListFragment extends Fragment {

    private CourseListViewModel dashboardViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel = ViewModelProviders.of(this).get(CourseListViewModel.class);
        View root = inflater.inflate(R.layout.fragment_course_list, container, false);

        SearchView searchView = root.findViewById(R.id.course_list_searchView);
        searchView.setSubmitButtonEnabled(true);
        searchView.setQueryHint("移动应用开发");

        final CourseList courseList = new CourseList();
        courseList.initCourseList();

        CourseAdapter courseAdapter = new CourseAdapter(this.getContext(), R.layout.course_item, CourseList.courses);
        ListView listView = root.findViewById(R.id.course_list_view);
        listView.setAdapter(courseAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                Bundle bundle = new Bundle();
                bundle.putLong("course_index", i);
                CourseDetailFragment courseDetailFragment = new CourseDetailFragment();
                courseDetailFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.course_detail_frameLayout, courseDetailFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        return root;
    }
}