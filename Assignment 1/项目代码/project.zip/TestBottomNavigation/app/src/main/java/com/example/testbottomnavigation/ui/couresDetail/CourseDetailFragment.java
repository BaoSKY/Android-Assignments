package com.example.testbottomnavigation.ui.couresDetail;

import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.testbottomnavigation.R;
import com.example.testbottomnavigation.domain.Course;
import com.example.testbottomnavigation.domain.CourseList;

public class CourseDetailFragment extends Fragment {

    private CourseDetailViewModel mViewModel;

    public static CourseDetailFragment newInstance() {
        return new CourseDetailFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_course_detail, container, false);
        Bundle bundle = getArguments();
        int index = bundle.getInt("course_index");
        Course course = CourseList.courses.get(index);

        TextView courseID = root.findViewById(R.id.course_detail_id_textView);
        TextView courseName = root.findViewById(R.id.course_detail_name_textView);
        TextView courseTeacher = root.findViewById(R.id.course_detail_teacher_textView);
        TextView courseCalender = root.findViewById(R.id.course_detail_calendar_textView);
        TextView courseInfo = root.findViewById(R.id.course_detail_info_textView);
        TextView courseSyllabus = root.findViewById(R.id.course_detail_syllabus_textView);

        courseID.setText(course.getID());
        courseName.setText(course.getName());
        courseTeacher.setText(course.getTeacher().getName());
        courseCalender.setText(course.getCalendar());
        courseInfo.setText(course.getInformation());
        courseSyllabus.setText(course.getSyllabus());
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(CourseDetailViewModel.class);
        // TODO: Use the ViewModel
    }

}
