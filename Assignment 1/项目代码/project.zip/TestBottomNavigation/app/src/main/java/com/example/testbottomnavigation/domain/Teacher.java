package com.example.testbottomnavigation.domain;

public class Teacher {
    private String ID;
    private String name;

    public Teacher(String ID, String name){
        this.ID = ID;
        this.name = name;
    }

    public void setID(String newID){
        this.ID = newID;
    }

    public String getID(){
        return this.ID;
    }

    public void setName(String newName){
        this.name = newName;
    }

    public String getName(){
        return this.name;
    }
}
