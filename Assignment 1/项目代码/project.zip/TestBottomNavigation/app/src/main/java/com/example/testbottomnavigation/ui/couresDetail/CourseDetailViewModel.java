package com.example.testbottomnavigation.ui.couresDetail;

import androidx.lifecycle.ViewModel;

public class CourseDetailViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
