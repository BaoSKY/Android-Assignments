package com.example.studycourse.Util;

/**
 *常量类
 *用来保存一些常量
 **/
public class Constants {
  public static final String EMAIL="17301101@bjtu.edu.cn";

  public static final String PASSWORD="123456abc";

}
