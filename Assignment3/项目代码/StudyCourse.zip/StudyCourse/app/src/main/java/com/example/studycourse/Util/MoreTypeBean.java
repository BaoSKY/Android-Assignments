package com.example.studycourse.Util;

public class MoreTypeBean {
    public int type;
    public String material;
}